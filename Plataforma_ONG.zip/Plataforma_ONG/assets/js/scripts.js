// scripts.js — máscaras simples e validação adicional
(function(){
  'use strict';

  function maskCPF(value){
    return value
      .replace(/\D/g,'')
      .replace(/(\d{3})(\d)/,'$1.$2')
      .replace(/(\d{3})\.(\d{3})(\d)/,'$1.$2.$3')
      .replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/,'$1.$2.$3-$4')
      .slice(0,14);
  }

  function maskPhone(v){
    v = v.replace(/\D/g,'');
    if(v.length>10){
      return v.replace(/(\d{2})(\d{5})(\d{4}).*/,'($1) $2-$3').slice(0,15);
    }
    return v.replace(/(\d{2})(\d{4})(\d{0,4}).*/,'($1) $2-$3').slice(0,14);
  }

  function maskCEP(v){
    return v.replace(/\D/g,'').replace(/(\d{5})(\d)/,'$1-$2').slice(0,9);
  }

  document.addEventListener('DOMContentLoaded', function(){
    var cpf = document.getElementById('cpf');
    var tel = document.getElementById('telefone');
    var cep = document.getElementById('cep');
    var form = document.getElementById('cadastroForm');

    if(cpf){
      cpf.addEventListener('input', function(e){ this.value = maskCPF(this.value); });
    }
    if(tel){
      tel.addEventListener('input', function(e){ this.value = maskPhone(this.value); });
    }
    if(cep){
      cep.addEventListener('input', function(e){ this.value = maskCEP(this.value); });
    }

    if(form){
      form.addEventListener('submit', function(e){
        if(!form.checkValidity()){
          e.preventDefault();
          var firstInvalid = form.querySelector(':invalid');
          if(firstInvalid){ firstInvalid.focus(); }
        } else {
          e.preventDefault();
          alert('Formulário válido! (simulação de envio)');
          form.reset();
        }
      });
    }
  });

})();
