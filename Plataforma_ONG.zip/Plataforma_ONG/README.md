# Plataforma ONG — Entrega 1 (HTML5 Semântico)

Repositório com a entrega 1 do projeto: plataforma web para ONGs — páginas estáticas com estrutura semântica, formulários e recursos front-end.

## Conteúdo
- `index.html` — página inicial institucional.
- `projetos.html` — listagem de projetos.
- `cadastro.html` — formulário de voluntariado/doação com validação e máscaras.
- `assets/css/styles.css`
- `assets/js/scripts.js`
- `assets/img/` — imagens em JPG e WebP (placeholders otimizados).

## Validação W3C
Os arquivos HTML foram preparados para seguir boas práticas HTML5. Recomenda-se, após qualquer alteração, validar no W3C Validator: https://validator.w3.org/

## Como usar
1. Baixe e extraia o ZIP.
2. Abra `index.html` no seu navegador.
3. Para versionar, crie um repositório no GitHub e faça `git push` seguindo as instruções do GitHub.

## Licença
Uso acadêmico.

